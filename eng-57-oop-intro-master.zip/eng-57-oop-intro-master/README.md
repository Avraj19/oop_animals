# Intro to OOP  

What is OOP,
Why OOP. 

How to OOP


### Class
What is a class? A class is like a cookie cutter or blue print for objects but not the object itself. 

What can you do with a cookie? 
    -   eat it!
    
### methods 
The actions or how an object behaves. 

So in the above example, .eat_cookie() could be a method inside the class Cookie


### Instance

### syntax


### Convention


## 4 Pillars

### Abstration 
- good naming
- good documentation 
- use of inheritance 


#### Polymorthism
- what is class polymorthism?
- what is method polymorthism? 

